package htl.plf2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class AddActivity extends AppCompatActivity {

    private EditText etName, etDay, etMonth, etYear;

    private Button btnOk, btnCancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        this.etName = this.findViewById(R.id.etName);
        this.etDay = this.findViewById(R.id.etDay);
        this.etMonth = this.findViewById(R.id.etMonth);
        this.etYear = this.findViewById(R.id.etYear);

        this.btnOk = this.findViewById(R.id.btnOk);
        this.btnCancel = this.findViewById(R.id.btnCancel);

        btnOk.setOnClickListener(view -> {
            // throw new Error("8ung !!! Der OK - Button beendet die Applikation !!1! ");

            Intent data = new Intent();
            data.putExtra("activity", "ADD");
            data.putExtra("name", this.etName.getText().toString());
            data.putExtra("day", this.etDay.getText().toString());
            data.putExtra("month", this.etMonth.getText().toString());
            data.putExtra("year", this.etYear.getText().toString());
            this.setResult(RESULT_OK, data);
            this.finish();
        });

        btnCancel.setOnClickListener(view -> {
            this.setResult(RESULT_CANCELED);
            this.finish();
        });
    }
}