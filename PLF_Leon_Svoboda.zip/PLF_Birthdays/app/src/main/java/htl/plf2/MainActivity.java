package htl.plf2;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.Toast;

import java.time.Month;
import java.util.ArrayList;
import java.util.Arrays;

import htl.plf2.data.Birthday;
import htl.plf2.data.BirthdayAdapter;

public class MainActivity extends AppCompatActivity {

    private ListView lvMain;

    private BirthdayAdapter adapter;

    private String[] months = {"Januar", "Februar", "März", "April", "Mai", "Juni",
            "Juli", "August", "September", "Oktober", "November", "Dezember"};

    ActivityResultLauncher<Intent> startForResult = this.registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if(result.getResultCode() == RESULT_OK) {
                    Intent data = result.getData();
                    if(result.getData() == null) return;
                    switch(data.getStringExtra("activity")) {
                        case "ADD":
                            try {
                                String name = data.getStringExtra("name");
                                int day = Integer.parseInt(data.getStringExtra("day"));
                                if(day > 31) throw new NumberFormatException("Tag zu groß!");
                                String month = data.getStringExtra("month");
                                if(!Arrays.asList(this.months).contains(month)) throw new NumberFormatException("Monat existiert nicht!");
                                int year = Integer.parseInt(data.getStringExtra("year"));
                                Birthday birthday = new Birthday();
                                birthday.setName(name);
                                birthday.setDay(day);
                                birthday.setMonth(month);
                                birthday.setYear(year);
                                MainActivity.this.adapter.add(birthday);
                            } catch(NumberFormatException e) {
                                Toast.makeText(MainActivity.this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                            }
                            break;
                    }
                }
            }
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.lvMain = this.findViewById(R.id.lvMain);

        this.adapter = new BirthdayAdapter(this);
        this.lvMain.setAdapter(this.adapter);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case R.id.menuAdd:
                this.startForResult.launch(new Intent(MainActivity.this, AddActivity.class));
                break;
            case R.id.menuM:
                for(int i = 0; i < this.adapter.getAll().size(); i++) {
                    Birthday birthday = this.adapter.getAll().get(i);
                    if(birthday.getName().contains("m") || birthday.getName().contains("M")) {
                       this.adapter.delete(birthday);
                    }
                }
                break;
            case R.id.menuEldest:
                int lowestYear = Integer.MAX_VALUE;
                StringBuilder builder = new StringBuilder();
                for(int i = 0; i < this.adapter.getAll().size(); i++) {
                    Birthday birthday = this.adapter.getAll().get(i);
                    if(birthday.getYear() < lowestYear) lowestYear = birthday.getYear();
                }
                for(Birthday birthday : this.adapter.getAll()) {
                    if(birthday.getYear() == lowestYear) builder.append(String.format("%s: %d. %s %d\n", birthday.getName(), birthday.getDay(), birthday.getMonth(), birthday.getYear()));
                }
                Toast.makeText(this, builder.toString().replaceAll("\n$", ""), Toast.LENGTH_LONG).show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }
}