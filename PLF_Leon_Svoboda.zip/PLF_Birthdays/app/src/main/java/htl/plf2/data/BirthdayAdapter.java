package htl.plf2.data;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;

import htl.plf2.R;

public class BirthdayAdapter extends BaseAdapter {

    ArrayList<Birthday> birthdayList;

    LayoutInflater layoutInflater;

    public BirthdayAdapter(Context context) {
        this.birthdayList = new ArrayList<>();
        this.layoutInflater = LayoutInflater.from(context);
    }

    public void add(Birthday ...tasks) {
        this.birthdayList.addAll(Arrays.asList(tasks));
        this.notifyDataSetChanged();
    }

    public void delete(int index) {
        this.birthdayList.remove(index);
        this.notifyDataSetChanged();
    }

    public void delete(Birthday birthday) {
        this.birthdayList.remove(birthday);
        this.notifyDataSetChanged();
    }

    public ArrayList<Birthday> getAll() {
        return this.birthdayList;
    }

    @Override
    public int getCount() {
        return birthdayList.size();
    }

    @Override
    public Object getItem(int position) {
        return birthdayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        TextView tvName, tvDate;
        if(convertView == null) {
            convertView = layoutInflater.inflate(R.layout.row, parent, false);
            tvName = convertView.findViewById(R.id.tvName);
            tvDate = convertView.findViewById(R.id.tvDate);

            convertView.setTag(R.id.tvName, tvName);
            convertView.setTag(R.id.tvDate, tvDate);
        } else {
            tvName = (TextView) convertView.getTag(R.id.tvName);
            tvDate = (TextView) convertView.getTag(R.id.tvDate);
        }
        Birthday birthday = birthdayList.get(position);
        tvName.setText(birthday.getName());
        tvDate.setText(birthday.formatDate());
        return convertView;
    }
}