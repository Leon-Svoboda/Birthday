package htl.plf2.data;

import java.util.Arrays;

public class Birthday {

    private String name, month;

    private int day, year;

    private static String[] allMonths = {"Jänner", "Februar", "März", "April", "Mai", "Juni", "Juli",
            "August", "September", "Oktober", "November", "Dezember"};

    public static Birthday from(String name, String day, String month, String year) throws IllegalArgumentException {
        Birthday birthday = new Birthday();
        try {
            birthday.setName(name);
            birthday.setDay(Integer.parseInt(day));
            birthday.setMonth(month);
            birthday.setYear(Integer.parseInt(year));
            if(Arrays.stream(allMonths).noneMatch(m -> !m.equals(month))) {
                System.out.println("8ung !!!  es funk tionirt ");
            }
        } catch (Exception e) {
            throw new IllegalArgumentException("Invalid Input");
        }
        return birthday;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String formatDate() {
        return String.format("%d. %s %d", this.day, this.month, this.year);
    }
}
